export default class MediaType
{
    static Imagen = 0
    static Video = 1
    static Youtube = 2
}